<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo e(config('app.name', 'Laravel')); ?> - Data Siswa</title>
    <link href="<?php echo e(asset('sbadmin2/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="<?php echo e(asset('sbadmin2/css/sb-admin-2.min.css')); ?>" rel="stylesheet">
</head>
<body id="page-top">
    <div id="wrapper">
        <?php echo $__env->make('admin.components.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php echo $__env->make('components.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <div class="container-fluid">
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">
                           Data Siswa
                        </h1>
                        <a href="<?php echo e(route('admin.siswa.create')); ?>" class="btn btn-sm btn-primary shadow-sm">
                            <i class="fas fa-plus fa-sm"></i> Tambah Siswa
                        </a>
                    </div>

                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <i class="fas fa-check-circle"></i> <?php echo e(session('success')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <div class="card shadow">
                        <div class="card-header py-3 bg-primary">
                            <h6 class="m-0 font-weight-bold text-white">
                                <i class="fas fa-table"></i> Daftar Siswa
                            </h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover table-bordered">
                                    <thead class="table-light">
                                        <tr>
                                            <th style="width: 3%">No</th>
                                            <th style="width: 10%">NIS</th>
                                            <th style="width: 15%">Username</th>
                                            <th style="width: 20%">Nama</th>
                                            <th style="width: 14%">Kelas</th>
                                            <th style="width: 15%">Keterangan</th>
                                            <th style="width: 15%">Tanggal Dibuat</th>
                                            <th style="width: 10%" class="text-center">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $siswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td class="text-center font-weight-bold"><?php echo e(($siswas->currentPage() - 1) * $siswas->perPage() + $key + 1); ?></td>
                                                <td>
                                                    <span class="badge badge-primary"><?php echo e($siswa->nis); ?></span>
                                                </td>
                                                <td>
                                                    <?php echo e($siswa->username ?? '-'); ?>

                                                </td>
                                                <td>
                                                    <strong><?php echo e($siswa->nama ?? '-'); ?></strong>
                                                </td>
                                                <td>
                                                    <span class="badge badge-info"><?php echo e($siswa->kelas ?? '-'); ?></span>
                                                </td>
                                                <td>
                                                    <small><?php echo e($siswa->keterangan ?? '-'); ?></small>
                                                </td>
                                                <td>
                                                    <small><?php echo e($siswa->created_at->format('d/m/Y H:i')); ?></small>
                                                </td>
                                                <td class="text-center">
                                                    <div class="d-flex justify-content-center" style="gap: 15px;">
                                                        <a href="<?php echo e(route('admin.siswa.edit', $siswa->nis)); ?>" class="btn btn-sm btn-warning" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" title="Edit">
                                                            <i class="fas fa-edit"></i> Edit
                                                        </a>
                                                        <form action="<?php echo e(route('admin.siswa.destroy', $siswa->nis)); ?>" method="POST" style="display:inline;">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-sm btn-danger" style="padding: 0.25rem 0.5rem; font-size: 0.75rem;" title="Hapus" onclick="return confirm('Apakah Anda yakin ingin menghapus siswa ini?')">
                                                                <i class="fas fa-trash"></i> Hapus
                                                            </button>
                                                        </form>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="8" class="text-center text-muted py-4">
                                                    <i class="fas fa-inbox"></i> Belum ada data siswa
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>

                            <?php if($siswas->hasPages()): ?>
                                <div class="d-flex justify-content-center mt-4">
                                    <?php echo e($siswas->links()); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('components.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top"><i class="fas fa-angle-up"></i></a>

    <script src="<?php echo e(asset('sbadmin2/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('sbadmin2/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('sbadmin2/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('sbadmin2/js/sb-admin-2.min.js')); ?>"></script>
</body>
</html>

<?php /**PATH C:\laragon\www\ukk_sarana\resources\views/admin/siswa/index.blade.php ENDPATH**/ ?>