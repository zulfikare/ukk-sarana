<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo e(config('app.name', 'Laravel')); ?> - Detail Pengaduan</title>
    <link href="<?php echo e(asset('sbadmin2/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="<?php echo e(asset('sbadmin2/css/sb-admin-2.min.css')); ?>" rel="stylesheet">
</head>
<body id="page-top">
    <div id="wrapper">
        <?php echo $__env->make('admin.components.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php echo $__env->make('components.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <div class="container-fluid">
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Detail Pengaduan</h1>
                        <a href="<?php echo e(route('admin.pengaduan.index')); ?>" class="btn btn-sm btn-secondary">
                            <i class="fas fa-arrow-left"></i> Kembali
                        </a>
                    </div>

                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-lg-8">
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">
                                        <i class="fas fa-file-alt"></i> Informasi Pengaduan
                                    </h6>
                                </div>
                                <div class="card-body">
                                    <div class="row mb-3">
                                        <div class="col-md-12">
                                            <strong>Kategori:</strong>
                                            <p><span class="badge badge-info"><?php echo e($pengaduan->kategori->ket_kategori); ?></span></p>
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <strong>Tanggal Dibuat:</strong>
                                            <p><?php echo e($pengaduan->created_at->format('d/m/Y H:i:s')); ?></p>
                                        </div>
                                        <div class="col-md-6">
                                            <strong>Status Saat Ini:</strong>
                                            <p>
                                                <?php if($pengaduan->status === 'Menunggu'): ?>
                                                    <span class="badge badge-warning">Menunggu</span>
                                                <?php elseif($pengaduan->status === 'Proses'): ?>
                                                    <span class="badge badge-info">Proses</span>
                                                <?php else: ?>
                                                    <span class="badge badge-success">Selesai</span>
                                                <?php endif; ?>
                                            </p>
                                        </div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <strong>Pelapor:</strong>
                                            <p><strong><?php echo e($pengaduan->siswa->nama ?? 'N/A'); ?></strong> (NIS: <?php echo e($pengaduan->nis); ?>)</p>
                                        </div>
                                        <div class="col-md-6">
                                            <strong>Lokasi:</strong>
                                            <p><?php echo e($pengaduan->lokasi ?? '-'); ?></p>
                                        </div>
                                    </div>

                                    <hr>

                                    <div class="mb-3">
                                        <strong>Isi Pengaduan:</strong>
                                        <div class="bg-light p-3 rounded mt-2">
                                            <p><?php echo e(nl2br(e($pengaduan->ket))); ?></p>
                                        </div>
                                    </div>

                                    <?php if($pengaduan->gambar): ?>
                                        <div class="mb-3">
                                            <strong>Gambar/Bukti:</strong>
                                            <div class="mt-2">
                                                <img src="<?php echo e(asset('storage/aspirasi/' . $pengaduan->gambar)); ?>" 
                                                     alt="Gambar Bukti" class="img-fluid rounded" style="max-width: 100%; max-height: 400px;">
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                    <?php if($pengaduan->feedback): ?>
                                        <div class="row mb-3">
                                            <div class="col-md-12">
                                                <strong>Feedback/Catatan:</strong>
                                                <div class="bg-light p-3 rounded mt-2">
                                                    <p><?php echo e(nl2br(e($pengaduan->feedback))); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4">
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">
                                        <i class="fas fa-tasks"></i> Respons Pengaduan
                                    </h6>
                                </div>
                                <div class="card-body">
                                    <?php if($pengaduan->status !== 'Selesai'): ?>
                                        <form method="POST" action="<?php echo e(route('admin.pengaduan.update', $pengaduan->id_aspirasi)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PATCH'); ?>
                                            <input type="hidden" name="id_kategori" value="<?php echo e($pengaduan->id_kategori); ?>">
                                            
                                            <div class="form-group mb-3">
                                                <label for="status" class="form-label"><strong>Ubah Status</strong></label>
                                                <select class="form-control" id="status" name="status" required>
                                                    <option value="<?php echo e($pengaduan->status); ?>" selected><?php echo e($pengaduan->status); ?></option>
                                                    <?php if($pengaduan->status !== 'Menunggu'): ?>
                                                        <option value="Menunggu">Menunggu</option>
                                                    <?php endif; ?>
                                                    <?php if($pengaduan->status !== 'Proses'): ?>
                                                        <option value="Proses">Proses</option>
                                                    <?php endif; ?>
                                                    <?php if($pengaduan->status !== 'Selesai'): ?>
                                                        <option value="Selesai">Selesai</option>
                                                    <?php endif; ?>
                                                </select>
                                            </div>

                                            <div class="form-group mb-3">
                                                <label for="feedback" class="form-label"><strong>Feedback/Catatan</strong></label>
                                                <textarea class="form-control <?php $__errorArgs = ['feedback'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                          id="feedback" name="feedback" rows="4" 
                                                          placeholder="Berikan feedback atau catatan untuk pengaduan ini..."><?php echo e(old('feedback', $pengaduan->feedback)); ?></textarea>
                                                <small class="form-text text-muted d-block mt-2">Feedback akan ditampilkan kepada pelapor</small>
                                                <?php $__errorArgs = ['feedback'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                            <button type="submit" class="btn btn-success btn-block">
                                                <i class="fas fa-save"></i> Simpan Feedback
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <div class="alert alert-success" role="alert">
                                            <i class="fas fa-check-circle"></i> <strong>Pengaduan ini telah selesai ditangani</strong>
                                        </div>
                                        <?php if($pengaduan->feedback): ?>
                                            <div class="mt-3">
                                                <strong>Feedback yang diberikan:</strong>
                                                <div class="bg-light p-3 rounded mt-2">
                                                    <p><?php echo e(nl2br(e($pengaduan->feedback))); ?></p>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('components.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top"><i class="fas fa-angle-up"></i></a>

    <script src="<?php echo e(asset('sbadmin2/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('sbadmin2/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('sbadmin2/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('sbadmin2/js/sb-admin-2.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\ukk_sarana\resources\views/admin/pengaduan/show.blade.php ENDPATH**/ ?>